
#' Create SAGA samples target file.
#'
#' \code{saga_gentargets} will automatically create an empty "SampleInformation.txt" file. If you chose to use this function a sample folder
#' with array files (*.txt) is needed. Each textfile must contain the full Agilent microarray information.
#'
#' \cr PLEASE NOTE: When the targets file is generated it cannot know about your sample batches/groups/vector or class information.
#' All settings are therefore set to "NA" and you'll have to change these parameters MANUALLY or SAGA analysis will fail.
#' You may use MS Excel or a text editor for doing this.
#'
#' If you plan on using \code{saga_gesea} for Geneset Enrichment Analysis at least two samples PLUS a MOCK control are needed. The control vector
#' should be named "MOCK" in the sample information file. Also, it's 'Class' is 'nontransforming'"' and its 'Group' has to be set to 1.
#' The other samples should be named according to your experimental setup or left 'NA'. Classes with 'NA' information will be predicted
#' during SAGA analysis. Check the saga_vignette for more information.
#'
#' We RECOMMEND that your classification experiment should include at least 2 to 3 MOCK controls, 2 to 3 RV.SF positive controls and 2 to 3
#' EFS controls. These controls are required for the batch correction algorithm and to ensure that your samples are properly represented in the
#' SAGA model.
#'
#' @param samplepath path to the saga data folder with the user samples.
#'
#' @return \code{targets} default target file for user samples.
#'
#' @export
#'
#'

saga_gentargets    <- function(samplepath){
  setwd(samplepath)

  if(!file.exists("SampleInformation.txt")){
    filelist            <- list.files(pattern = ".txt")
    elements            <- length(filelist)

    cnames              <- c("SAMPLE_ID", "Filename","Batch", "Group", "Vector", "Class")

    targets <- NULL
    for (i in 1:elements){

      f1                <- filelist[i]
      f1                <- gsub("*.txt", "",f1)
      f1                <- paste("X",f1, sep="")

      f2                <- filelist[i]

      targets           <- rbind(targets, data.frame(f1, f2, NA, NA, NA, NA) )
    }
    colnames(targets)   <- cnames

    write.table(targets, file = "SampleInformation.txt", row.names = FALSE, sep = "\t")

    message("============================================================================")
    message("=============================  IMPORTANT! ==================================")
    message("============================================================================")
    message("Empty 'SampleInformation.txt' file successfully created.")
    message("Please modify manually for SAGA. SAGA will NOT work if this file is missing.")
    message("Check saga_vignette or ?saga_gentargets help for details.")
    message("============================================================================")

  }else{
    message("There is already a 'SampleInformation.txt' file in the folder, so SAGA will use it!")
  }

}











