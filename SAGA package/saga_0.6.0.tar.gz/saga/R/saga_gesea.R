#'
#' Train & optimize SAGA model with own data.
#'
#' With this function the user can specify additional positive or negative controls for his data. Further,
#' all labelled data will be appended to the SAGA default data set and will therefore contribute to the model building process of the SVM.
#' Also, the function optimizes/tunes the SVM parameters to find the best possible model for the underlying data.
#' The result (a prediction) will not only show classes but also probabilities for each sample. This additional information may offer another
#' edge for risk assessment.
#'
#' \code{saga_optmodel}
#'
#' @param samplepath path to the saga data folder with the user samples.
#' @param SIF sample information file (based on the SAGA_USER_Samples.txt" file ).
#'
#' @return \code{result} GESEA result - will also be saved into the sample folder.
#'
#' @import limma
#' @import Biobase
#' @import phenoTest
#' @import gridExtra
#'
#' @export
#'

saga_gesea    <- function(samplepath, SIF){

  ################################################################################################
  ############################### 9. SAGA-GSEA  ##################################################
  ################################################################################################

  ################################################################################################
  #### 1. Data handling ##########################################################################
  ################################################################################################
  # all the following is new in V6:
  sets       <- saga::sets
  SAGA.CORE  <- setNames(split(sets, seq(nrow(sets))), rownames(sets))   # GeneSets have to be stored in a list object


  ### 1.1. Read in files from user and loop over all batches separately from here on ##############
  #################################################################################################
   setwd(samplepath)
   maxBatch   <- max(as.integer(SIF$Batch))   # how many assays / batches


  for(i in 1:maxBatch) {
    SIF.i <- SIF[SIF$Batch==i,]
    RAW.i <- read.maimages(files=SIF.i$Filename, path=".", source="agilent.median", green.only=T,
                           columns=list(G="gMedianSignal"), annotation=c("ProbeName", "GeneName"))
    colnames(RAW.i) <- row.names(SIF.i)
    #### 2.1. Normalize, average ###################################################################
    RMA.i <- normalizeBetweenArrays(RAW.i, method="quantile")                 # quantil normalize
    RMA.i <- avereps(RMA.i,ID= RMA.i$genes$ProbeName)                                # average replicates to one value for each probe
    matrix.gsea <- RMA.i$E                                               # extract log2 expression values

    #### 2.3. make ExpressionSet (Biobase) object ##################################################
    metadata  <- data.frame(labelDescription= rep(NA,dim(SIF.i)[2]),row.names=colnames(SIF.i))   # varMetadata: empty, but required
    phenoData <- new("AnnotatedDataFrame",data=SIF.i, varMetadata=metadata)     # annotatedDataFrame for the annotation of the samples
    eset.gsea <- ExpressionSet(assayData = matrix.gsea, phenoData = phenoData)  # this is the ExpressionSet required for phenoTest

    #### 2.4. make ePheno object: contains the FCs associated with Group variable ##################
    vars2test   <- list(ordinal="Group")    # Variables (here: Groups) to test against MOCK, which are always Group = 1 in the SIF
    epheno.gsea <- ExpressionPhenoTest(eset.gsea,vars2test,p.adjust.method='BH')

    #### 2.5 GSEA #################################################################################
    SAGA.GSEA <- gsea(x=epheno.gsea, gsets=SAGA.CORE ,B=2000,                  # calculate GSEA-scores based on the FC in the epheno object
                      center = TRUE, test = "perm", p.adjust.method='BH')

    result            <- summary(SAGA.GSEA)[,c(1,2,3,5,8)]                     # extract results (only NES- normalized enrichment scores)
    result$pred.class <- ifelse(result$nes>0,"transforming","nontransforming") # prediction based on NES

    #### 2.6 output ###############################################################################
    Group <- NULL    ### pull out the Group index number from the result table

    for (a in 1:nrow(result)) {Group[a] <- unlist(strsplit(as.character(result$variable[a]), ".", fixed = TRUE))[2] }
      result$Group     <- Group

      SIF.sub           <- SIF.i[SIF.i$Group != 1, c(3,4,1) ]                     # pull out info of tested Groups
      SIF.sub$SampleID  <- row.names(SIF.sub)
      result.m          <- merge(SIF.sub,result, by.x="Group", by.y = "Group") # merge result with SIF for SampleIDs and FileNames
      write.table(result.m, file = paste("Results_SAGA.GSEA_Batch_",i,".txt",sep = ""), sep="\t",row.names = FALSE)
      # make pdf report
      pdf(file=paste("SAGA.GSEA_Batch_",i,".pdf",sep = ""),useDingbats = F,width = 10, height = 10)
      grid.table(result.m,rows = NULL)
      plot(SAGA.GSEA,es.nes='nes',selGsets='SAGA.CORE')
      dev.off()
  }


  message("======================================")
  message("============== Success! ==============")
  message("======================================")
  message("GESA analysis complete!               ")
  message("The results are in your sample folder.")
  message("Thank you for using SAGA package!     ")
  message("======================================")

  return(result)
}

