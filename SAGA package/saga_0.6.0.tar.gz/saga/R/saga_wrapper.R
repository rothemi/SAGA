#'
#' SAGA Wrapper
#'
#' The \code{saga_wrapper} function integrates all SAGA functions into one. With this function you are not as flexible as
#' with the single ones but you can run the analysis/ classification in one step.
#' However, this requires a complete SampleInformatin.txt file. For GESEA analysis the SampleInformation file must also fulfill
#' the neccessary criteria. See saga_vignette for more information.
#'
#' \code{saga_wrapper}
#'
#' @param samplepath sample path
#' @param doGESEA Can be 0 or 1. If set to 1, GESEA analysis will be added to the analysis.
#' @param showPCA Can be 0 or 1. If set to 1 (default) PCA plot will be shown.
#'
#' @return \code{output} optimized SVM model for classification.
#'
#' @import limma
#' @import sva
#' @import e1071
#' @import Biobase
#' @import phenoTest
#' @import gridExtra
#'
#' @export
#'

saga_wrapper   <- function(samplepath, showPCA=1, doGESEA=0){

  rawdata        <- saga_import(samplepath, showjoint=0)

  eset.user      <- rawdata$eset.user
  pData.user     <- rawdata$pData.user
  pData.joint    <- rawdata$pData.joint
  SIF            <- rawdata$SIF
  print("+++ sample data read +++")

  # normalize saga data
  normalized     <- saga_norm(rawdata$SAGA_RAW, rawdata$pData.joint, rawdata$matrix.user, normplot=0)
  matrix.SAGA    <- normalized$matrix.SAGA
  matrix.user    <- normalized$matrix.user
  print("+++ normalization complete +++")

  # remove batch effects
  batchnorm      <- saga_batch(matrix.SAGA, matrix.user, SIF)
  matrix.SAGA    <- batchnorm$matrix.SAGA
  matrix.user    <- batchnorm$matrix.user
  print("+++ batch effects removed +++")

  # filtering & model building
  if(showPCA==1){
    NN           <- saga_sampling(matrix.SAGA, matrix.user, pData.joint, pData.user, showPCA=1)
  }else{
    NN           <- saga_sampling(matrix.SAGA, matrix.user, pData.joint, pData.user, showPCA=0)
  }
  matrix.train   <- NN$matrix.train
  labels.train   <- NN$labels.train
  matrix.unknown <- NN$matrix.unknown
  matrix.Top12   <- NN$matrix.Top12

  # Array predictions with optimized SVM parameters (default settings)
  output         <- saga_predict(matrix.train, labels.train, matrix.unknown, writeFile=1)
  print("+++ SVM prediction complete +++")

  # Predictions with own neg/pos controls and grid optimization; may be used without controls
  optPred        <- saga_optmodel(pData.joint, matrix.Top12, showbest=0, writeFile=1)
  print("+++ SVM grid optimization & prediction complete +++")
  print("+++ SAGA ANALYSIS COMPLETE! +++")

  if(doGESEA == 1){
  gesea_results   <- saga_gesea(samplepath, SIF)
  }


  return(list(predictions=output, optPred=optPred) )

}
