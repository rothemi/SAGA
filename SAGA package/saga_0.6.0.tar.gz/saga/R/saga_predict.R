
#' Prediction of sample arrays with the SAGA model.
#'
#' \code{saga_predict} uses a Support Vector Machine (SVM) with a radial kernel to classify user samples either as transforming or nontransforming.
#' The SVM model is built with the integrated SAGA training data set and a toplist of relevant probes which are able to differentiate assay data
#' into the mentioned risk states. The SVM is further optimized on the SAGA training data. Use at your own risk!
#'
#' @param matrix.train normalized, probe-averaged and batch-corrected SAGA training data.
#' @param labels.train class labels (factors) for SAGA training data. Can either be "transforming" or "nontransforming".
#' @param matrix.unknown matrix of sample data with array names as row names and probes as column names.
#' @param writeFile can be 1 or 0. In case of 1 it will write the prediction result to a txt file in the sample folder. Default is 0.
#'
#' @return \code{predictions} Data frame with three columns. Column one shows the sample names, the second column shows the decision values of
#' the svm function and column thress shows the predictions for the query assays either as transforming or nontransforming.
#'
#' @import e1071
#' @export
#'


saga_predict <- function(matrix.train, labels.train, matrix.unknown, writeFile=0) {

  ################################################################################################
  #### 7. e1071 SVM training, tuning & prediction ################################################
  ################################################################################################

  # new in V6: tune model and take best hyperparameters instead of using fixed gamma and cost:
  tunectrl_1  <- tune.control(sampling="cross", cross = 10, nrepeat = 5, best.model = TRUE, performances = TRUE) # new in V6
  gammalist_1 <- c(0.03,0.04,0.05,0.06,0.07,0.08,0.09,0.1,0.15,0.2,0.25,0.3,0.4,0.5)    # new in V6
  costlist_1  <- c(0.1,0.5,1,2,3,4,5,10)                                                # new in V6

  set.seed (1234)
  svm_tune_1  <- tune(svm, matrix.train, labels.train, kernel="radial",                      # new in V6
                      ranges=list(gamma=gammalist_1,cost = costlist_1), tunecontrol = tunectrl_1)

  cat("Tuning successful, Gamma=",svm_tune_1$best.parameters$gamma,", Cost=", svm_tune_1$best.parameters$cost,   # new in V6
      ", Accuracy 10fold CV n5 =", 1-svm_tune_1$best.performance)

  model  <- svm(matrix.train,labels.train, probability = TRUE,type="C-classification",         # new in V6
                gamma = svm_tune_1$best.parameters$gamma, cost = svm_tune_1$best.parameters$cost)

  output <- data.frame(attr(predict(model, matrix.unknown, probability= T), "probabilities"),
                       predict(model, matrix.unknown))


  if(writeFile == 1){
    ## new in V4: output into file
    write.table(output, file = paste("Predictions_SAGA.SVMrad.txt",sep = ""), sep="\t",row.names = TRUE,col.names=NA)
    message("'Predictions_SAGA.SVMrad_fixed.txt' written to sample folder!")
  }else{}


  return(output)

}








