#' Import user data for SAGA model building
#'
#' The \code{saga_import} function loads SAGA data from textfiles in a user specified path and prepares the necessary objects for later
#' classification of unknown arrays.
#'
#' In addition to the sample files, a user-defined targets file must be provided. It contains the necessary sample names, batch
#' information etc. You can use the \code{saga_targets} function to create a targets file for you. However, in any case, the
#' targets file must be named "SAGA_USER_Samples.txt" and must be placed in the same folder together with the sample files.
#'
#' \cr PLEASE NOTE: The saga package works with raw Agilent data. There is no need for prior data preprocessing.
#' The saga function will take care of this.
#'
#' @param samplepath path to the saga data folder with the user samples.
#' @param showjoint can be 1 or 0. In case of 1 it will show a boxplot of the unnormalised data (model + user data). Default is 0.
#'
#'
#' @return \code{matrix.user}   n-by-m matrix user data.
#' @return \code{pData.joint}   joint target matrix of both SAGA data and user samples.
#' @return \code{pData.user}    target matrix of user samples.
#' @return \code{pData}         phenotype target matrix of SAGA data.
#'
#' @return \code{eset.user}     expression set of user data.
#' @return \code{SIF}           sample information file (based on the SAGA_USER_Samples.txt" file ).
#' @return \code{SAGA_RAW}      SAGA raw data.
#'
#' @import limma
#'
#' @export
#'

saga_import   <- function(samplepath, showjoint=0){

  setwd(samplepath)

  ################################################################################################
  #### 1. Data handling ##########################################################################
  ################################################################################################

  ### the following files should be build into the R package as data files:
  pData       <- saga::pData
  Annotation  <- saga::Annotation
  Top12       <- saga::Top12
  SAGA_Data   <- saga::SAGA_Data
  SAGA_RAW    <- as.matrix(SAGA_Data[,-1])
  row.names(SAGA_RAW) <- SAGA_Data$PROBE_ID


  ### Read in files from user: assume that they are in the working directory #####################
  ################################################################################################
  SIF                     <- read.delim("SampleInformation.txt",row.names=1,header=TRUE,sep="\t", stringsAsFactors = F)
  pData.user              <- read.delim("SampleInformation.txt",row.names=1,header=TRUE,sep="\t", stringsAsFactors = F)
  pData.user$Batch        <- pData.user$Batch + 8
  pData.user$IVIM_Color   <- rep("#000000", nrow(pData.user))
  pData.user$Design_Color <- rep("#000000", nrow(pData.user))

  eset.user <- read.maimages(files=pData.user$Filename, path=".", source="agilent.median", green.only=T,
                             columns=list(G="gMedianSignal"), annotation=c("ProbeName", "GeneName"))

  colnames(eset.user)    <- row.names(pData.user)
  matrix.user            <- eset.user$E
  row.names(matrix.user) <- eset.user$genes$ProbeName
  matrix.user            <- avereps(matrix.user, ID= row.names(matrix.user))

  stopifnot(all(row.names(SAGA_RAW) %in% row.names(matrix.user)))
  matrix.user <- matrix.user[row.names(SAGA_RAW),]


  ### Make joint sample information file #########################################################
  ################################################################################################
  stopifnot(all(colnames(pData.user) == colnames(pData)))
  pData.joint <- rbind(pData,pData.user)



  ### output Boxplot of RAW-Intensities as QC function einbauen:
  if(showjoint ==1){
    boxplot(log2(cbind(SAGA_RAW,matrix.user)),
            col       = pData.joint$IVIM_Color,
            names     = pData.joint$Name,
            boxwex    = 0.6,
            cex.axis  = 0.5,
            las       = 2,
            outline   = FALSE,
            main      = "SAGA joint data set (raw)")
  }else{}

  return( list(matrix.user   = matrix.user,
               pData.joint   = pData.joint,
               pData.user    = pData.user,
               pData         = pData,
               eset.user     = eset.user,
               SIF           = SIF,
               SAGA_RAW      = SAGA_RAW ) )
}



