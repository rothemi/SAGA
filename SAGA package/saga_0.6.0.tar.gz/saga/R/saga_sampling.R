
#' Sample preparation of the joint SAGA data set.
#'
#' \code{saga_sampling} will prepare training and testing data of the joint SAGA data set. An internal process
#' is used to filter all data for candidate probes suited for classification of array data into transforming/nontransforming.
#' The list cannot be changed in this version and the package is optimized for this specific gene set. Also, a PCA plot may be
#' generated to monitor the generalized context of the sample data within the SAGA training set.
#'

#' @param matrix.SAGA n-by-m matrix of log2 transformed, normalized and batch-corrected SAGA data.
#' @param matrix.user n-by-m matrix of log2 transformed, normalized and batch-corrected user data.
#' @param pData phenotype target matrix of SAGA data
#' @param pData.user target matrix of user samples.
#' @param showPCA can be 1 or 0. In case of 1 it will show a PCA plot with sample data and SAGA training data. Default is 0.
#'
#' @return \code{matrix.train} normalized, probe-averaged and batch-corrected SAGA training data.
#' @return \code{labels.train} class labels (factors) for SAGA training data. Can either be "transforming" or "nontransforming".
#' @return \code{matrix.unknown} matrix of sample data with array names as row names and probes as column names.
#' @return \code{matrix.Top12} matrix of top9 filtered genes for SAGA data and usersamples.
#'
#' @export
#'

saga_sampling    <- function(matrix.SAGA, matrix.user, pData.joint, pData.user,  showPCA=0){

  ################################################################################################
  #### 4. PCA on CORE Genes  #####################################################################
  ################################################################################################
  pData        <- saga::pData
  matrix.Top12 <- cbind(matrix.SAGA, matrix.user)[row.names(Top12),]
  index        <- nrow(pData)+nrow(pData.user)   # new in V6: nrow(pData)


  ################################################################################################
  #### 6. PCA on CORE Genes  #####################################################################
  ################################################################################################
  if(showPCA == 1){
    pdf(file="PCA_SAGA.pdf",useDingbats = F,width = 6, height = 5)
    pca          <- prcomp(t(matrix.Top12))
    explV        <- round(pca$sdev^2 / sum(pca$sdev^2)*100,2)

    plot(pca$x, ylim=c(-3,2), pch=16, col=pData.joint$Design_Color, cex=1, xlab=paste("PC1 (",explV[1],"%)",sep=""), ylab=paste("PC2 (",explV[2],")",sep="") )
    text(pca$x[c((nrow(pData)+1):index),c(1:2)], labels=pData.user$Filename, cex= 0.6, pos=3, offset = 0.3)
    title("PCA plot SAGA Model")

    legend("bottomright",
           legend = c("transforming","mock","neutral","new samples"),
           col    = unique(pData.joint$Design_Color),
           pch    = 16,
           bty    = "n",
           cex    = 1)
    grid()
    dev.off()


    # plot also in the plot window
    plot(pca$x,
         pch    = 16,
         col    = pData.joint$Design_Color,
         cex    = 1.3,
         xlab   = paste("PC1 (",explV[1],"%)",sep=""),
         ylab   = paste("PC2 (",explV[2],"%)",sep="") )

    text(pca$x[c((nrow(pData)+1):index),c(1:2)], labels=pData.user$Filename, cex= 1, pos=3, offset = 0.8)
    title("PCA plot SAGA Model")

    legend("bottomright",
           legend = c("transforming","mock","neutral","new samples"),
           col    = unique(pData.joint$Design_Color),
           pch    = 16,
           bty    = "n",
           cex    = 1)
    grid()

  }else{}


  ################################################################################################
  #### 5. split into Prediction and Known Sets ###################################################
  ################################################################################################

  ## new in V5: train and test data directly from the separate datasets- no indexing necessary
  matrix.train   <- t(matrix.SAGA[row.names(saga::Top12),]) # Changed in V5 to matrix.SAGA
  labels.train   <- as.factor(pData$Class)
  matrix.unknown <- t(matrix.user[row.names(saga::Top12),]) # Changed in V5 to matrix.user

  return(list(matrix.train=matrix.train, labels.train=labels.train, matrix.unknown=matrix.unknown, matrix.Top12=matrix.Top12))


}
