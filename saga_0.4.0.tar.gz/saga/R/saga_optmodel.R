#'
#' Train & optimize SAGA model with own data.
#'
#' With this function the user can specify additional positive or negative controls for his data. Further,
#' all labelled data will be appended to the SAGA default data set and will therefore contribute to the model building process of the SVM.
#' Also, the function optimizes/tunes the SVM parameters to find the best possible model for the underlying data.
#' The result (a prediction) will not only show classes but also probabilities for each sample. This additional information may offer another
#' edge for risk assessment.
#'
#' \code{saga_optmodel}
#'
#' @param pData.joint joint target matrix of both SAGA data and user samples.
#' @param matrix.Top9 matrix of top9 filtered genes for SAGA data and usersamples.
#' @param showbest shows optimized (best) SVM parameters (default setting is 0).
#' @param showsummary shows SVM model summary (default setting is 0).
#'
#' @return \code{optPred} optimized SVM model for classification.
#'
#' @import e1071
#'
#' @export
#'




saga_optmodel    <- function(pData.joint, matrix.Top9, showbest=0, writeFile=0){



  ################################################################################################
  #### 8. e1071 train new SVM  with grid search ##################################################
  ################################################################################################

  #### 8.1 new split into training and unknown data ##############################################
  ################################################################################################

  pData.known    <- subset(pData.joint, !is.na(pData.joint$Class))
  pData.unknown  <- subset(pData.joint, is.na(pData.joint$Class))

  matrix.known   <- t(matrix.Top9[,row.names(pData.known)])    # changed in V4 to "matrix.known" since "matrix.train has been used above already
  labels.known   <- as.factor(pData.known$Class)                # changed in V4 to "labels.known"
  matrix.unknown <- t(matrix.Top9[,row.names(pData.unknown)])



  #### 8.2 tune and train SVM ####################################################################
  ################################################################################################
  tunectrl  <- tune.control(sampling="cross", cross = 10, nrepeat = 5, best.model = TRUE, performances = TRUE)
  gammalist <- c(0.05,0.06,0.07,0.08,0.09,0.1,0.15,0.2,0.25,0.3,0.4,0.5)   # changed in V4
  costlist  <- c(0.5,1,2,3,4,5,10)                                    # changed in V4

  set.seed (1)
  svm_tune  <- tune(svm,matrix.known, labels.known, kernel="radial",
                    ranges=list(gamma=gammalist,cost = costlist), tunecontrol = tunectrl)


  ### new in V5: return Best Parameters when SVM has been tuned
  if(showbest == 1){
    cat("Tuning successful, Gamma=",svm_tune$best.parameters$gamma,", Cost=", svm_tune$best.parameters$cost,
        ", Accuracy 10fold CV n5 =", 1-svm_tune$best.performance)
  }else{}

  ### train svm with best hyperparameters
  svm_fit <- svm(matrix.known,labels.known, probability = TRUE,type="C-classification",
                 gamma = svm_tune$best.parameters$gamma,
                 cost = svm_tune$best.parameters$cost)


  #### 8.3 e1071 SVM prediction    ################################################################
  ################################################################################################

  ## changed in V4 to "prediction"
  optPred    <- data.frame(attr(predict(svm_fit, matrix.unknown, probability= T), "probabilities"),
                           predicted.as=predict(svm_fit, matrix.unknown))

  if(writeFile == 1){
    write.table(optPred, file = paste("Predictions_SAGA.SVMrad_tuned.txt",sep = ""), sep="\t",row.names = TRUE,col.names=NA)
    message("'Predictions_SAGA.SVMrad_tuned.txt' written to sample folder!")
  }else{}

  return(optPred)

}


