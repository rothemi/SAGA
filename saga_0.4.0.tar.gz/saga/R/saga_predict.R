
#' Prediction of sample arrays with the SAGA model.
#'
#' \code{saga_predict} uses a Support Vector Machine (SVM) with a radial kernel to classify user samples either as transforming or nontransforming.
#' The SVM model is built with the integrated SAGA training data set and a toplist of relevant probes which are able to differentiate assay data
#' into the mentioned risk states. The SVM is further optimized on the SAGA training data. Use at your own risk!
#'
#' @param matrix.train normalized, probe-averaged and batch-corrected SAGA training data.
#' @param labels.train class labels (factors) for SAGA training data. Can either be "transforming" or "nontransforming".
#' @param matrix.unknown matrix of sample data with array names as row names and probes as column names.
#' @param writeFile can be 1 or 0. In case of 1 it will write the prediction result to a txt file in the sample folder. Default is 0.
#'
#' @return \code{predictions} Data frame with three columns. Column one shows the sample names, the second column shows the decision values of
#' the svm function and column thress shows the predictions for the query assays either as transforming or nontransforming.
#'
#' @import e1071
#' @export
#'


saga_predict <- function(matrix.train, labels.train, matrix.unknown, writeFile=0) {


  ################################################################################################
  #### 7. e1071 SVM prediction    ################################################################
  ################################################################################################

  model        <- svm(matrix.train, labels.train, kernel="radial", cost=2, gamma=0.08,cross = 10,
                      type="C-classification", probability=TRUE)

  predictions  <- data.frame(attr(predict(model, matrix.unknown, probability= T), "probabilities"),
                             predicted.as=predict(model, matrix.unknown))

  if(writeFile == 1){
    ## new in V4: output into file
    write.table(predictions, file = paste("Predictions_SAGA.SVMrad_fixed.txt",sep = ""), sep="\t",row.names = TRUE, col.names = NA)
    message("'Predictions_SAGA.SVMrad_fixed.txt' written to sample folder!")
  }else{}

  return(predictions)

}








