#' Normalize joint SAGA data sets
#'
#' \code{saga_norm} uses both user data and SAGA data to perform quantile normalization. Multiple probes within arrays are averaged.
#'
#' @param SAGA_RAW      SAGA raw data.
#' @param pData.joint   joint target matrix of both SAGA data and user samples.
#' @param matrix.user   n-by-m matrix user data..
#' @param normplot      can be 1 or 0. In case of 1 it will show a boxplot of the normalized data. Default is 0.
#'
#' @return \code{matrix.user}   n-by-m matrix of log2 transformed and normalized user data.
#' @return \code{matrix.SAGA}   n-by-m matrix of log2 transformed and normalized SAGA data.
#'
#' @import limma
#' @import bapred
#'
#' @export
#'

saga_norm <- function(SAGA_RAW, pData.joint, matrix.user, normplot=0) {

  ################################################################################################
  #### 2.  Addon Quantile Normalization   ########################################################
  ###################################################################################ä############

  qunorm.SAGA  <- qunormtrain(t(SAGA_RAW))    # make qunorm object containing normalized data and parameters for addon normalization
  matrix.SAGA  <- log2(t(qunorm.SAGA$xnorm))  # extract normalized data
  matrix.user  <- log2(t(qunormaddon(qunorm.SAGA, t(matrix.user)))) # addon normalization of test data


  #### QC after normalization
  if(normplot == 1)
    boxplot(cbind(matrix.SAGA,matrix.user),
            col      = pData.joint$IVIM_Color,
            names    = pData.joint$Name,boxwex=0.6,
            cex.axis = 0.5,
            las      = 2,
            outline  = FALSE,
            main     = "SAGA joint data set (normalized)")

  return(list(matrix.user=matrix.user, matrix.SAGA=matrix.SAGA))

}








