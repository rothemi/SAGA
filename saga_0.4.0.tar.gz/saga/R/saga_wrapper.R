#'
#' SAGA Wrapper
#'
#' The \code{saga_wrapper} function integrates all SAGA functions into one. With this function you are not as flexible as
#' with the single ones but you can run the analysis/ classification in one step.
#' However, this requires a complete SampleInformatin.txt file. For GESEA analysis the SampleInformation file must also fulfill
#' the neccessary criteria. See saga_vignette for more information.
#'
#' \code{saga_wrapper}
#'
#' @param samplepath sample path
#' @param doGESEA Can be 0 or 1. If set to 1, GESEA analysis will be added to the analysis.
#'
#' @return \code{output} optimized SVM model for classification.
#'
#' @import limma
#' @import sva
#' @import e1071
#' @import Biobase
#' @import phenoTest
#' @import gridExtra
#'
#' @export
#'

saga_wrapper   <- function(samplepath, doGESEA=0){


  rawdata         <- saga_import(samplepath, showjoint=0)

  normalized      <- saga_norm(rawdata$SAGA_RAW, rawdata$pData.joint, rawdata$matrix.user, normplot=0)

  batchnorm       <- saga_batch(rawdata$pData, normalized$matrix.SAGA, rawdata$matrix.user, rawdata$SIF)

  NN              <- saga_sampling(batchnorm$matrix.SAGA,
                                   batchnorm$matrix.user,
                                   rawdata$pData.joint,
                                   rawdata$pData,
                                   rawdata$pData.user,
                                   showPCA=1)

  predictions     <- saga_predict(NN$matrix.train, NN$labels.train, NN$matrix.unknown, writeFile=1)

  optPred         <- saga_optmodel(rawdata$pData.joint, NN$matrix.Top9, showbest=0,   writeFile=1)

  if(doGESEA == 1){
  gesea_results   <- saga_gesea(samplepath, rawdata$eset.user, rawdata$SIF)
  }


  return(list(predictions=predictions, optPred=optPred) )

}
