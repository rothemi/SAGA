
#' Batch correction of joint SAGA data sets.
#'
#' \code{saga_batch} removes batch effects from the joint data set. For each sample, the user must specify a batch number in the
#' "SAGA_USER_Samples.txt" file. If no batch numbers are available - you'll still have to provide a number for the samples. You can use
#' any integer number beginning with 1. The batch correction of the data set relies on the ComBat algorithm/package.
#'
#' @param pData phenotype target matrix of SAGA data.
#' @param matrix.SAGA n-by-m matrix of log2 transformed and normalized SAGA data.
#' @param matrix.user n-by-m matrix of log2 transformed and normalized user data.
#' @param SIF sample information file (based on the SAGA_USER_Samples.txt" file ).
#'
#' @return \code{matrix.user} n-by-m matrix of log2 transformed, normalized and batch-corrected user data.
#' @return \code{matrix.SAGA} n-by-m matrix of log2 transformed, normalized and batch-corrected SAGA data.
#'
#' @import sva
#' @import bapred
#'
#' @export
#'


saga_batch     <- function(pData, matrix.SAGA, matrix.user, SIF){

  ###############################################################################################
  #### 3. Addon COMBAT  #########################################################################
  ###############################################################################################
  # new in V5:
  batch.SAGA   <- as.factor(pData$Batch)                         # batches of trainings data only
  combat.SAGA  <- combatba(t(matrix.SAGA), batch = batch.SAGA)   # create COMBAT object containing batch corrected data and parameters for addon correction
  matrix.user  <- t(combatbaaddon(combat.SAGA, t(matrix.user), batch = as.factor(SIF$Batch)))  # addon COMBAT of test data
  matrix.SAGA  <- t(combat.SAGA$xadj)
  colnames(matrix.SAGA) <- row.names(pData)


  return(list(matrix.user=matrix.user, matrix.SAGA= matrix.SAGA) )

}


